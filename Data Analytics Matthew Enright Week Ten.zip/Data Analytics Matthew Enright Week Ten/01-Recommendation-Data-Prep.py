#!/usr/bin/env python
# coding: utf-8

# # Recommendation - Data Preparation 🎬

# ---

# <img src="https://cdn-images-1.medium.com/max/1200/0*ePGWILY6GyplT-nn" />

# ---

# In the next few challenges, you will build a powerful **movie recommender**.
# 
# We will use the open-source library [LightFM](https://github.com/lyst/lightfm) which provides easy python implementation of **hybrid** recommendation engines.
# 
# In this first part, we will prepare the data in order to train efficiently of the model.
# 
# We let you load the data `movies` and `ratings` downloaded from the **small** [movielens dataset](https://grouplens.org/datasets/movielens/).
# 
# 

# In[ ]:


## Instlatiion of light fm ##
get_ipython().system('pip install lightfm')


# In[33]:


## Importation of libraries ##
import pandas as pd


# In[34]:


## Loading of the movies and ratings dataset ##
ratings = pd.read_csv("ratings.csv")
movies = pd.read_csv("movies.csv")
links = pd.read_csv("links.csv")


# **Q1**. What are the different types of recommendation models? Explain briefly with your own words the differences between them.

# In[35]:


###  Explain briefly with your own words the differences recommendation models between them ###

#There are several differences between three different recommendations models 
#
#The first recommendation model is called Content-Based-Recommendations, which is a model 
# used to recommend entities based on relation/similarities between user-features and item-features
#
#The second recommendation model is called rating-based-recommendation, which is a model based on
#recommending entities accordingly to the users past behaviour based on stored past behaviour data.
#
#The final recommendation model is called the clustering-based-recommendation, which is a model 
#based on recommendation based on the cluster/area within a matrix that are based on rating data.


# **Q1bis**. What data is expected by the LightFM `fit` method? Especially, how does the train data should be organized, and what should be the type of the train dataset? 

# In[36]:


#The data expected by the use method of Fit within LightFM model
#is the conversion of the input data into a matrix that is structured based on weights of 
#interactions and relations. It creates the feature mappings. 

#The train data should include a sprase matrix detailing positive
#though 1, and negative interactions though -1. 


# In[37]:


ratings.dtypes


# **Q2**. Explore `movies` and `ratings`, what do those datasets contain? How are they organized?

# In[38]:


#The datasets of ratings is a dataset consisting of 100,836 rows and four columns. It includes 
#userId, movieID, rating and timestamp. The movie ID is int, while title genres object. 
#They are organised by 1 index, and four rows.

#The dataset of rating is a dataset consisting of 9742 rows and three columns. It includes movieId,
#title, and genres. The userId, movieID, and timestamp are all in int64 format. While rating is 
#in float64 format. 


# ---

# ### Q3 & Q4 are optional
# > you can come back to it if you have time after having finished the whole project of the day

# We created a few utils functions for you in `utils.py` script. Especially:
# - `threshold_interactions_df`:
# > Limit interactions df to minimum row and column interactions
# 
# **Q3**. Open `src/utils.py` file, and have a look at the documentation of this function to understand its goal and how it works.
# 
# Have a look the code to understand fully how it works. You should be familiar with everything.
# 
# What does represent the variable `sparsity`? What is the range of values in which sparsity can be?

# In[ ]:





# **Q4**. Create a new DataFrame `ratings_thresh`, that filters `ratings` with only:
# - users that rated strictly more than 4 movies
# - movies that have been rated at least 10 times
# 
# How many users/movies remain in this new dataset?

# In[39]:


from utils import threshold_interactions_df

ratings_thresh_df = threshold_interactions_df(ratings,"userId","movieId",5,10)

print(len(ratings_thresh_df.userId.unique()),
          len(ratings_thresh_df.movieId.unique()))


# **Q5**. In order to fit a [LightFM](https://lyst.github.io/lightfm/docs/home.html) model, we need to transform our Dataframe to a sparse matrix (cf. below). This is not straightforward so we included the function `df_to_matrix` in `utils.py`.
# 
# > 🔦 **Hint**:  Sparse matrices are just **big matrices with a lot of zeros or empty values**.
# > 
# > Existing tools (Pandas DataFrame, Numpy arrays for example) are not suitable for manipulating this kind of data. So we will use [Scipy sparse matrices](https://docs.scipy.org/doc/scipy-0.14.0/reference/sparse.html).
# >
# > It exists many different "types" of sparse matrices (CSC, CSR, COO, DIA, etc.). You don't need to know them. Just know that it corresponds to different formats with different methods of manipulation, slicing, indexing, etc.
# 
# > 🔦 **Hint 2**:  By going from a DataFrame to a sparse matrix, you will lose the information of the ids (userId and movieId), you will only deal with indices (row number and column number). Therefore, the `df_to_matrix` function also returns dictionaries mapping indexes to ids (ex: uid_to_idx mapping userId to index of the matrix) 
# 
# 
# Have a look at the util function documentation, and use it to create 5 new variables:
# - a final sparse matrix `ratings_matrix` (this will be the data used to train the model)
# - the following utils mappers:
#     - `uid_to_idx`
#     - `idx_to_uid`
#     - `mid_to_idx`
#     - `idx_to_mid`

# In[40]:


from utils import df_to_matrix

ratings_matrix, uid_to_idx,idx_to_uid,mid_to_idx, idx_to_mid = df_to_matrix(ratings_thresh_df,'userId','movieId')
ratings_matrix


# **Q6**.
# - On the one side, find what movies did the userId 4 rate?
# 
# - On the other side, what is the value of `ratings_matrix` for:
#     - userId = 4 and movieId=1
#     - userId = 4 and movieId=2
#     - userId = 4 and movieId=21
#     - userId = 4 and movieId=32
#     - userId = 4 and movieId=126
# 
# Conclude on the values signification in `ratings_matrix`

# In[41]:


ratings[ratings.userId==4]


# In[42]:


for mid in [1,2,21,32,126]:
   print("for MID",mid)
   print("Matrix value is",ratings_matrix[uid_to_idx[4],mid_to_idx[mid]])


# **Q5**. Now that you have a `ratings_matrix` in the correct format, let's save it in pickle format:
# - Create a variable `dst_dir` corresponding to the path of the folder `data/netflix` located at the root of the repository
# - **Verify that this is the correct path**
# - Save the ratings_matrix in pickle (as `ratings_matrix.pkl`) in this corresponding directory

# In[43]:


directory = "./data"
import pickle


# In[44]:


pickle.dump(ratings_matrix, open(directory + "/ratings_matrix.pkl","wb"))


# **Q6**. Save also all mappings objects into pickle (`idx_to_mid`, `mid_to_idx`, `uid_to_idx`, `idx_to_uid`) as it will be useful for later.

# In[45]:


pickle.dump(idx_to_mid, open(directory + "/idx_to_mid.pkl","wb"))
pickle.dump(mid_to_idx, open(directory + "/mid_to_idx.pkl","wb"))
pickle.dump(uid_to_idx, open(directory + "/uid_to_idx.pkl","wb"))
pickle.dump(idx_to_uid, open(directory + "/idx_to_uid.pkl","wb"))


# Up to next challenge now! 🍿
